﻿using Api.Comun.Interfaces;
using Api.Comun.Modelos.Pedidos;
using Api.Entidades;
using Api.Comun.Metodos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Api.Controllers;

[Route("detalle-pedidos")]
public class DetallePedidosController : ControllerBase
{
    private readonly IAplicacionBdContexto _contexto;

    public DetallePedidosController(IAplicacionBdContexto contexto)
    {
        _contexto = contexto;
    }

    [HttpGet]
    public async Task<List<BuscarDetallePedidoDto>> ObtenerDetalles()
    {
        var lista = await _contexto.DetallePedidos
            .Include(d => d.Producto)
            .ToListAsync();

        return lista.ConvertAll(d => d.ConvertirDto());
    }

    [HttpDelete("{id}")]
    public async Task<bool> EliminarDetalle(int id, CancellationToken cancelacionToken)
    {
        var detalle = await _contexto.DetallePedidos.FirstOrDefaultAsync(d => d.Id == id, cancelacionToken);
        if (detalle == null) return false;

        _contexto.DetallePedidos.Remove(detalle);
        await _contexto.SaveChangesAsync(cancelacionToken);

        return true;
    }
}
