﻿using Api.Comun.Interfaces;
using Api.Comun.Modelos.Pagos;
using Api.Entidades;
using Api.Comun.Metodos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Api.Controllers;

[Route("pagos")]
public class PagosController : ControllerBase
{
    private readonly IAplicacionBdContexto _contexto;

    public PagosController(IAplicacionBdContexto contexto)
    {
        _contexto = contexto;
    }

    [HttpGet]
    public async Task<List<BuscarPagoDto>> ObtenerPagos(int? pedidoId)
    {
        var query = _contexto.Pagos.AsQueryable();

        if (pedidoId.HasValue)
        {
            query = query.Where(p => p.PedidoId == pedidoId.Value);
        }

        var lista = await query.ToListAsync();
        return lista.ConvertAll(p => p.ConvertirDto());
    }

    [HttpGet("{slug}")]
    public async Task<BuscarPagoDto> ObtenerPago(string slug, CancellationToken cancelacionToken)
    {
        var pago = await _contexto.Pagos.FirstOrDefaultAsync(p => p.Slug == slug, cancelacionToken);
        return pago?.ConvertirDto() ?? new BuscarPagoDto();
    }

    [HttpPost]
    public async Task<string> RegistrarPago([FromBody] CrearPagoDto dto, CancellationToken cancelacionToken)
    {
        var nuevoPago = new Pago
        {
            PedidoId = dto.PedidoId,
            MetodoPago = dto.MetodoPago,
            FechaPago = DateTime.UtcNow,
            Monto = dto.Monto,
            EstadoPago = dto.EstadoPago
        };

        await _contexto.Pagos.AddAsync(nuevoPago, cancelacionToken);
        await _contexto.SaveChangesAsync(cancelacionToken);

        return nuevoPago.Slug;
    }

    [HttpPut("{slug}")]
    public async Task<BuscarPagoDto> ModificarPago([FromBody] ModificarPagoDto dto, CancellationToken cancelacionToken)
    {
        var pago = await _contexto.Pagos.FirstOrDefaultAsync(p => p.Slug == dto.Slug, cancelacionToken);
        if (pago == null) return new BuscarPagoDto();

        pago.MetodoPago = dto.MetodoPago;
        pago.Monto = dto.Monto;
        pago.EstadoPago = dto.EstadoPago;

        await _contexto.SaveChangesAsync(cancelacionToken);
        return pago.ConvertirDto();
    }
}
