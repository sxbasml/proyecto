﻿using Api.Comun.Interfaces;
using Api.Comun.Modelos.Pedidos;
using Api.Entidades;
using Api.Comun.Metodos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Api.Controllers;

[Route("pedidos")]
public class PedidosController : ControllerBase
{
    private readonly IAplicacionBdContexto _contexto;

    public PedidosController(IAplicacionBdContexto contexto)
    {
        _contexto = contexto;
    }

    [HttpGet]
    public async Task<List<BuscarPedidoDto>> ObtenerPedidos(int? usuarioId)
    {
        var query = _contexto.Pedidos.AsQueryable();

        if (usuarioId.HasValue)
        {
            query = query.Where(p => p.UsuarioId == usuarioId.Value);
        }

        var lista = await query.Include(p => p.Detalles).ToListAsync();
        return lista.ConvertAll(p => p.ConvertirDto());
    }

    [HttpGet("{slug}")]
    public async Task<BuscarPedidoDto> ObtenerPedido(string slug, CancellationToken cancelacionToken)
    {
        var pedido = await _contexto.Pedidos
            .Include(p => p.Detalles)
            .FirstOrDefaultAsync(p => p.Slug == slug, cancelacionToken);

        return pedido?.ConvertirDto() ?? new BuscarPedidoDto();
    }

    [HttpPost]
    public async Task<string> RegistrarPedido([FromBody] CrearPedidoDto dto, CancellationToken cancelacionToken)
    {
        var nuevoPedido = new Pedido
        {
            UsuarioId = dto.UsuarioId,
            FechaPedido = DateTime.UtcNow,
            Total = dto.Total,
            Estado = dto.Estado,
            Detalles = dto.Detalles.Select(d => new DetallePedido
            {
                ProductoId = d.ProductoId,
                Cantidad = d.Cantidad,
                PrecioUnitario = d.PrecioUnitario
            }).ToList()
        };

        await _contexto.Pedidos.AddAsync(nuevoPedido, cancelacionToken);
        await _contexto.SaveChangesAsync(cancelacionToken);

        return nuevoPedido.Slug;
    }

    [HttpPut("{slug}")]
    public async Task<BuscarPedidoDto> ModificarPedido([FromBody] ModificarPedidoDto dto, CancellationToken cancelacionToken)
    {
        var pedido = await _contexto.Pedidos
            .Include(p => p.Detalles)
            .FirstOrDefaultAsync(p => p.Slug == dto.Slug, cancelacionToken);

        if (pedido == null)
            return new BuscarPedidoDto();

        pedido.Estado = dto.Estado;
        pedido.Total = dto.Total;

        // Si deseas modificar los detalles, puedes limpiar y volver a agregar
        pedido.Detalles.Clear();
        pedido.Detalles = dto.Detalles.Select(d => new DetallePedido
        {
            ProductoId = d.ProductoId,
            Cantidad = d.Cantidad,
            PrecioUnitario = d.PrecioUnitario
        }).ToList();

        await _contexto.SaveChangesAsync(cancelacionToken);

        return pedido.ConvertirDto();
    }
}
