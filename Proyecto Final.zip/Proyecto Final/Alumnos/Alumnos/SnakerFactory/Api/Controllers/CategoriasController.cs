﻿using Api.Comun.Interfaces;
using Api.Comun.Metodos;
using Api.Comun.Modelos.Categorias;
using Api.Entidades;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Api.Controllers;

[Route("categorias")]
public class CategoriasController : ControllerBase
{
    private readonly IAplicacionBdContexto _contexto;

    public CategoriasController(IAplicacionBdContexto contexto)
    {
        _contexto = contexto;
    }

    [HttpGet]
    public async Task<List<BuscarCategoriaDto>> ObtenerCategorias()
    {
        var lista = await _contexto.Categorias.ToListAsync();
        return lista.ConvertAll(c => c.ConvertirDto());
    }

    [HttpGet("{slug}")]
    public async Task<BuscarCategoriaDto> ObtenerCategoria(string slug, CancellationToken cancelacionToken)
    {
        var categoria = await _contexto.Categorias.FirstOrDefaultAsync(c => c.Slug == slug, cancelacionToken);
        return categoria?.ConvertirDto() ?? new BuscarCategoriaDto();
    }

    [HttpPost]
    public async Task<string> RegistrarCategoria([FromBody] CrearCategoriaDto dto, CancellationToken cancelacionToken)
    {
        var categoria = new Categoria
        {
            Nombre = dto.Nombre
        };

        await _contexto.Categorias.AddAsync(categoria, cancelacionToken);
        await _contexto.SaveChangesAsync(cancelacionToken);

        return categoria.Slug;
    }

    [HttpPut("{slug}")]
    public async Task<BuscarCategoriaDto> ModificarCategoria([FromBody] ModificarCategoriaDto dto, CancellationToken cancelacionToken)
    {
        var categoria = await _contexto.Categorias.FirstOrDefaultAsync(c => c.Slug == dto.Slug, cancelacionToken);
        if (categoria == null) return new BuscarCategoriaDto();

        categoria.Nombre = dto.Nombre;

        await _contexto.SaveChangesAsync(cancelacionToken);
        return categoria.ConvertirDto();
    }
}
