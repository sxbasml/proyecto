﻿using Api.Comun.Interfaces;
using Api.Comun.Modelos.Carritos;
using Api.Entidades;
using Api.Comun.Metodos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Api.Controllers;

[Route("carrito-detalles")]
public class CarritoDetallesController : ControllerBase
{
    private readonly IAplicacionBdContexto _contexto;

    public CarritoDetallesController(IAplicacionBdContexto contexto)
    {
        _contexto = contexto;
    }

    [HttpGet]
    public async Task<List<BuscarCarritoDetalleDto>> ObtenerDetalles()
    {
        var lista = await _contexto.CarritoDetalles
            .Include(d => d.Producto)
            .ToListAsync();

        return lista.ConvertAll(d => d.ConvertirDto());
    }

    [HttpDelete("{id}")]
    public async Task<bool> EliminarDetalle(int id, CancellationToken cancelacionToken)
    {
        var detalle = await _contexto.CarritoDetalles.FirstOrDefaultAsync(d => d.Id == id, cancelacionToken);
        if (detalle == null) return false;

        _contexto.CarritoDetalles.Remove(detalle);
        await _contexto.SaveChangesAsync(cancelacionToken);

        return true;
    }
}
