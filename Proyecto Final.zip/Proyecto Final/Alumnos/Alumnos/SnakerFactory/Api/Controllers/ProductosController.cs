﻿using Api.Comun.Interfaces;
using Api.Comun.Metodos;
using Api.Comun.Modelos.Productos;
using Api.Entidades;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Api.Controllers;

[Route("productos")]
public class ProductosController : ControllerBase
{
    private readonly IAplicacionBdContexto _contexto;

    public ProductosController(IAplicacionBdContexto contexto)
    {
        _contexto = contexto;
    }

    [HttpGet]
    public async Task<List<BuscarProductoDto>> ObtenerProductos(string? nombre)
    {
        var query = _contexto.Producto.AsQueryable();

        if (!string.IsNullOrEmpty(nombre))
        {
            query = query.Where(p => p.Nombre.Contains(nombre));
        }

        var lista = await query.ToListAsync();
        return lista.ConvertAll(p => p.ConvertirDto());
    }

    [HttpGet("{slug}")]
    public async Task<BuscarProductoDto> ObtenerProducto(string slug, CancellationToken cancelacionToken)
    {
        var producto = await _contexto.Producto.FirstOrDefaultAsync(p => p.Slug == slug, cancelacionToken);
        return producto?.ConvertirDto() ?? new BuscarProductoDto();
    }

    [HttpPost]
    public async Task<string> RegistrarProducto([FromBody] CrearProductoDto dto, CancellationToken cancelacionToken)
    {
        var producto = new Producto
        {
            Nombre = dto.Nombre,
            Descripcion = dto.Descripcion,
            Precio = dto.Precio,
            Marca = dto.Marca,
            Talla = dto.Talla,
            Stock = dto.Stock,
            ImagenUrl = dto.ImagenUrl,
            CategoriaId = dto.CategoriaId
        };

        await _contexto.Producto.AddAsync(producto, cancelacionToken);
        await _contexto.SaveChangesAsync(cancelacionToken);

        return producto.Slug;
    }

    [HttpPut("{slug}")]
    public async Task<BuscarProductoDto> ModificarProducto([FromBody] ModificarProductoDto dto, CancellationToken cancelacionToken)
    {
        var producto = await _contexto.Producto.FirstOrDefaultAsync(p => p.Slug == dto.Slug, cancelacionToken);
        if (producto == null) return new BuscarProductoDto();

        producto.Nombre = dto.Nombre;
        producto.Descripcion = dto.Descripcion;
        producto.Precio = dto.Precio;
        producto.Marca = dto.Marca;
        producto.Talla = dto.Talla;
        producto.Stock = dto.Stock;
        producto.ImagenUrl = dto.ImagenUrl;
        producto.CategoriaId = dto.CategoriaId;

        await _contexto.SaveChangesAsync(cancelacionToken);
        return producto.ConvertirDto();
    }
}
