﻿using Api.Comun.Interfaces;
using Api.Comun.Modelos.Carritos;
using Api.Entidades;
using Api.Comun.Metodos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Api.Controllers;

[Route("carritos")]
public class CarritosController : ControllerBase
{
    private readonly IAplicacionBdContexto _contexto;

    public CarritosController(IAplicacionBdContexto contexto)
    {
        _contexto = contexto;
    }

    [HttpGet]
    public async Task<List<BuscarCarritoDto>> ObtenerCarritos(int? usuarioId)
    {
        var query = _contexto.Carritos.Include(c => c.Detalles).AsQueryable();

        if (usuarioId.HasValue)
        {
            query = query.Where(c => c.UsuarioId == usuarioId.Value);
        }

        var lista = await query.ToListAsync();
        return lista.ConvertAll(c => c.ConvertirDto());
    }

    [HttpGet("{slug}")]
    public async Task<BuscarCarritoDto> ObtenerCarrito(string slug, CancellationToken cancelacionToken)
    {
        var carrito = await _contexto.Carritos
            .Include(c => c.Detalles)
            .FirstOrDefaultAsync(c => c.Slug == slug, cancelacionToken);

        return carrito?.ConvertirDto() ?? new BuscarCarritoDto();
    }

    [HttpPost]
    public async Task<string> RegistrarCarrito([FromBody] CrearCarritoDto dto, CancellationToken cancelacionToken)
    {
        var carrito = new Carrito
        {
            UsuarioId = dto.UsuarioId,
            Detalles = dto.Detalles.Select(d => new CarritoDetalle
            {
                ProductoId = d.ProductoId,
                Cantidad = d.Cantidad
            }).ToList()
        };

        await _contexto.Carritos.AddAsync(carrito, cancelacionToken);
        await _contexto.SaveChangesAsync(cancelacionToken);

        return carrito.Slug;
    }

    [HttpPut("{slug}")]
    public async Task<BuscarCarritoDto> ModificarCarrito([FromBody] ModificarCarritoDto dto, CancellationToken cancelacionToken)
    {
        var carrito = await _contexto.Carritos
            .Include(c => c.Detalles)
            .FirstOrDefaultAsync(c => c.Slug == dto.Slug, cancelacionToken);

        if (carrito == null)
            return new BuscarCarritoDto();

        // Vaciar detalles existentes
        carrito.Detalles.Clear();

        // Suponiendo que dto.Detalles es una lista con los detalles a asignar
        // Aquí deberías mapear cada dto.Detalle a entidad DetalleCarrito, ejemplo:
        carrito.Detalles = dto.Detalles.Select(d => new CarritoDetalle
        {
            // Asignar propiedades según dto d
            ProductoId = d.ProductoId,
            Cantidad = d.Cantidad,
            // ... otras propiedades necesarias
        }).ToList();

        await _contexto.SaveChangesAsync(cancelacionToken);

        // Retornar el dto convertido de carrito actualizado
        return carrito.ConvertirDto();  // Asegúrate de tener el método de extensión ConvertirDto para Carrito
    }
}
