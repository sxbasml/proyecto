﻿using Api.Entidades;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Api.Persistencia.Configuraciones;

public class OrdenConfiguracion
{
    public void Configure(EntityTypeBuilder<Pedido> constructor)
    {
        constructor.HasKey(o => o.Id);

        constructor.HasOne(o => o.Usuario)
            .WithMany()
            .HasForeignKey(o => o.UsuarioId);

        constructor.HasMany(o => o.Detalles)
     .WithOne(detalle => detalle.Pedido);
    }
}
