﻿using Api.Entidades;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Api.Persistencia.Configuraciones;

public class CarritoConfiguracion
{
    public void Configure(EntityTypeBuilder<Carrito> constructor)
    {
        constructor.HasKey(c => c.Id);

        constructor.HasOne(c => c.Usuario)
            .WithMany()
            .HasForeignKey(c => c.UsuarioId);

        constructor.HasMany(c => c.Detalles)
            .WithOne(cd => cd.Carrito);
    }
}
