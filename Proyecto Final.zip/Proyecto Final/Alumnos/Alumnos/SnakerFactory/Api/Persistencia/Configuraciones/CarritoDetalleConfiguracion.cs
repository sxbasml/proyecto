﻿using Api.Entidades;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Api.Persistencia.Configuraciones;

public class CarritoDetalleConfiguracion
{
    public void Configure(EntityTypeBuilder<CarritoDetalle> constructor)
    {
        constructor.HasKey(cd => cd.Id);

        constructor.HasOne(cd => cd.Carrito)
            .WithMany(c => c.Detalles)
            .HasForeignKey(cd => cd.CarritoId);

        constructor.HasOne(cd => cd.Producto)
            .WithMany()
            .HasForeignKey(cd => cd.ProductoId);
    }
}
