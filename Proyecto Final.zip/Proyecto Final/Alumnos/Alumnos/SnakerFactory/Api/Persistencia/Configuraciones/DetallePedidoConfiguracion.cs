﻿using Api.Entidades;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Api.Persistencia.Configuraciones;

public class DetalleOrdenConfiguracion
{
    public void Configure(EntityTypeBuilder<DetallePedido> constructor)
    {
        constructor.HasKey(d => d.Id);

        constructor.HasOne(d => d.Pedido)
            .WithMany(o => o.Detalles)
            .HasForeignKey(d => d.PedidoId);

        constructor.HasOne(d => d.Producto)
            .WithMany()
            .HasForeignKey(d => d.ProductoId);
    }
}
