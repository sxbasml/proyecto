﻿using Api.Entidades;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Api.Persistencia.Configuraciones;

public class PagoConfiguracion
{
    public void Configure(EntityTypeBuilder<Pago> constructor)
    {
        constructor.HasKey(p => p.Id);

        constructor.HasOne(p => p.Pedido)
            .WithMany()
            .HasForeignKey(p => p.PedidoId);
    }
}
