﻿using Api.Entidades;

namespace Api.Comun.Modelos.Pedidos;

public class BuscarPedidoDto
{
    public string Slug { get; set; }
    public int UsuarioId { get; set; }
    public DateTime FechaOrden { get; set; }
    public decimal Total { get; set; }
    public string Estado { get; set; }
    public List<BuscarDetallePedidoDto> Detalles { get; set; }

    public static BuscarPedidoDto ConvertirDto(Pedido pedido) => new()
    {
        Slug = pedido.Slug,
        UsuarioId = pedido.UsuarioId,
        FechaOrden = pedido.FechaPedido,
        Total = pedido.Total,
        Estado = pedido.Estado,
        Detalles = pedido.Detalles?.ConvertAll(BuscarDetallePedidoDto.ConvertirDto) ?? new()
    };
}
