﻿using Api.Entidades;

namespace Api.Comun.Modelos.Carritos;

public class BuscarCarritoDetalleDto
{
    public int ProductoId { get; set; }
    public string NombreProducto { get; set; }
    public int Cantidad { get; set; }

    public static BuscarCarritoDetalleDto ConvertirDto(CarritoDetalle detalle) => new()
    {
        ProductoId = detalle.ProductoId,
        NombreProducto = detalle.Producto?.Nombre ?? "",
        Cantidad = detalle.Cantidad
    };
}
