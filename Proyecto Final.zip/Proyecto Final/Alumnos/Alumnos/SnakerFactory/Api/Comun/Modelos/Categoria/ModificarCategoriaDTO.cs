﻿namespace Api.Comun.Modelos.Categorias;

public class ModificarCategoriaDto
{
    public string Slug { get; set; }
    public string Nombre { get; set; }
}
