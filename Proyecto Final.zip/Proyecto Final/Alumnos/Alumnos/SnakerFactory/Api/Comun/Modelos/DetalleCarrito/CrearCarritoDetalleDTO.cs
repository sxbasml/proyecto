﻿namespace Api.Comun.Modelos.Carritos;

public class CrearCarritoDetalleDto
{
    public int ProductoId { get; set; }
    public int Cantidad { get; set; }
}
