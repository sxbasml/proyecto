﻿namespace Api.Comun.Modelos.Pedidos;

public class ModificarPedidoDto
{
    public string Slug { get; set; }
    public decimal Total { get; set; }
    public string Estado { get; set; }
    public List<CrearDetallePedidoDto> Detalles { get; set; }
}
