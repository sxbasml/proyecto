﻿using Api.Entidades;

namespace Api.Comun.Modelos.Pagos;

public class BuscarPagoDto
{
    public string Slug { get; set; }
    public int PedidoId { get; set; }
    public DateTime FechaPago { get; set; }
    public decimal Monto { get; set; }
    public string MetodoPago { get; set; }
    public string EstadoPago { get; set; }

    public static BuscarPagoDto ConvertirDto(Pago pago) => new()
    {
        Slug = pago.Slug,
        PedidoId = pago.PedidoId,
        FechaPago = pago.FechaPago,
        Monto = pago.Monto,
        MetodoPago = pago.MetodoPago,
        EstadoPago = pago.EstadoPago
    };
}
