﻿namespace Api.Comun.Modelos.Carritos;

public class CrearCarritoDto
{
    public int UsuarioId { get; set; }
    public List<CrearCarritoDetalleDto> Detalles { get; set; }
}
