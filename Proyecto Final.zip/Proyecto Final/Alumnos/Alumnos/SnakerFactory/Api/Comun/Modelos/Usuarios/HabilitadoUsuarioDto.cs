namespace Api.Comun.Modelos.Usuarios;

public class HabilitadoUsuarioDto
{
    public string Slug { get; set; }
    public bool Habilitado { get; set; }
}