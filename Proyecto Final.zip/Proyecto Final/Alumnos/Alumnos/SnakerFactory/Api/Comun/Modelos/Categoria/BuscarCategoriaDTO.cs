﻿using Api.Entidades;

namespace Api.Comun.Modelos.Categorias;

public class BuscarCategoriaDto
{
    public string Slug { get; set; }
    public string Nombre { get; set; }

    public static BuscarCategoriaDto ConvertirDto(Categoria categoria) => new()
    {
        Slug = categoria.Slug,
        Nombre = categoria.Nombre
    };
}
