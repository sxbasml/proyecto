﻿namespace Api.Comun.Modelos.Categorias;

public class CrearCategoriaDto
{
    public string Nombre { get; set; }
}
