﻿using Api.Entidades;

namespace Api.Comun.Modelos.Pedidos;

public class BuscarDetallePedidoDto
{
    public int ProductoId { get; set; }
    public string NombreProducto { get; set; }
    public int Cantidad { get; set; }
    public decimal PrecioUnitario { get; set; }

    public static BuscarDetallePedidoDto ConvertirDto(DetallePedido detalle) => new()
    {
        ProductoId = detalle.ProductoId,
        NombreProducto = detalle.Producto?.Nombre ?? "",
        Cantidad = detalle.Cantidad,
        PrecioUnitario = detalle.PrecioUnitario
    };
}
