﻿namespace Api.Comun.Modelos.Pedidos;

public class CrearPedidoDto
{
    public int UsuarioId { get; set; }
    public decimal Total { get; set; }
    public string Estado { get; set; }
    public List<CrearDetallePedidoDto> Detalles { get; set; }
}
