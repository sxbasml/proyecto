namespace Api.Comun.Modelos;

public class IdentidadAjuste
{
    public string Secreto { get; init; }
    public int Expiracion { get; init; }
    public string EstampaSeguridad { get; init; }
}