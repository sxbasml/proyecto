﻿namespace Api.Comun.Modelos.Pagos;

public class ModificarPagoDto
{
    public string Slug { get; set; }
    public decimal Monto { get; set; }
    public string MetodoPago { get; set; }
    public string EstadoPago { get; set; }
}
