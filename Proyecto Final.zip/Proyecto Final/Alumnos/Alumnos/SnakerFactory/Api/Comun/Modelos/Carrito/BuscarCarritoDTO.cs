﻿using Api.Entidades;

namespace Api.Comun.Modelos.Carritos;

public class BuscarCarritoDto
{
    public string Slug { get; set; }
    public int UsuarioId { get; set; }
    public List<BuscarCarritoDetalleDto> Detalles { get; set; }

    public static BuscarCarritoDto ConvertirDto(Carrito carrito) => new()
    {
        Slug = carrito.Slug,
        UsuarioId = carrito.UsuarioId,
        Detalles = carrito.Detalles?.ConvertAll(BuscarCarritoDetalleDto.ConvertirDto) ?? new()
    };
}
