﻿namespace Api.Comun.Modelos.Pedidos;

public class CrearDetallePedidoDto
{
    public int ProductoId { get; set; }
    public int Cantidad { get; set; }
    public decimal PrecioUnitario { get; set; }
}
