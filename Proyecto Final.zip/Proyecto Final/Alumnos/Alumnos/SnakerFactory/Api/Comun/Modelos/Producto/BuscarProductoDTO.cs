﻿using Api.Entidades;

namespace Api.Comun.Modelos.Productos;

public class BuscarProductoDto
{
    public string Slug { get; set; }
    public string Nombre { get; set; }
    public string Descripcion { get; set; }
    public decimal Precio { get; set; }
    public int Stock { get; set; }
    public string CategoriaNombre { get; set; }

    public static BuscarProductoDto ConvertirDto(Producto producto) => new()
    {
        Slug = producto.Slug,
        Nombre = producto.Nombre,
        Descripcion = producto.Descripcion,
        Precio = producto.Precio,
        Stock = producto.Stock,
        CategoriaNombre = producto.Categoria?.Nombre ?? ""
    };
}
