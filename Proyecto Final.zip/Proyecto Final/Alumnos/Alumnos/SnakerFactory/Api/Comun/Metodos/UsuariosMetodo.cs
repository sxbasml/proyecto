﻿using Api.Comun.Modelos.Usuarios;
using Api.Entidades;

namespace Api.Comun.Metodos;

public static class UsuarioMetodos
{
    public static BuscarUsuariosDto ConvertirDto(this Usuario entidad)
    {
        return new BuscarUsuariosDto
        {
            Slug = entidad.Slug,
            Nombre = $"{entidad.Nombre} {entidad.ApellidoPaterno} {entidad.ApellidoMaterno}"
        };
    }
}
