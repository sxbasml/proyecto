﻿using Api.Comun.Modelos.Carritos;
using Api.Entidades;

namespace Api.Comun.Metodos;

public static class CarritoMetodos
{
    public static BuscarCarritoDto ConvertirDto(this Carrito entidad)
    {
        return new BuscarCarritoDto
        {
            Slug = entidad.Slug,
            UsuarioId = entidad.UsuarioId,
            Detalles = entidad.Detalles?.ConvertAll(x => x.ConvertirDto()) ?? new()
        };
    }
}
