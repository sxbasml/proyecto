﻿using Api.Comun.Modelos.Categorias;
using Api.Entidades;

namespace Api.Comun.Metodos;

public static class CategoriaMetodos
{
    public static BuscarCategoriaDto ConvertirDto(this Categoria entidad)
    {
        return new BuscarCategoriaDto
        {
            Slug = entidad.Slug,
            Nombre = entidad.Nombre
        };
    }
}
