﻿using Api.Comun.Modelos.Pagos;
using Api.Entidades;

namespace Api.Comun.Metodos;

public static class PagoMetodos
{
    public static BuscarPagoDto ConvertirDto(this Pago entidad)
    {
        return new BuscarPagoDto
        {
            Slug = entidad.Slug,
            PedidoId = entidad.PedidoId,
            FechaPago = entidad.FechaPago,
            Monto = entidad.Monto,
            MetodoPago = entidad.MetodoPago,
            EstadoPago = entidad.EstadoPago
        };
    }
}
