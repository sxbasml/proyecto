﻿using Api.Comun.Modelos.Pedidos;
using Api.Entidades;

namespace Api.Comun.Metodos;

public static class DetallePedidoMetodos
{
    public static BuscarDetallePedidoDto ConvertirDto(this DetallePedido entidad)
    {
        return new BuscarDetallePedidoDto
        {
            ProductoId = entidad.ProductoId,
            NombreProducto = entidad.Producto?.Nombre ?? "",
            Cantidad = entidad.Cantidad,
            PrecioUnitario = entidad.PrecioUnitario
        };
    }
}
