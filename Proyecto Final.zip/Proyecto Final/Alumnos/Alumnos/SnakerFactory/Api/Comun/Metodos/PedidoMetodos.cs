﻿using Api.Comun.Modelos.Pedidos;
using Api.Entidades;

namespace Api.Comun.Metodos;

public static class PedidoMetodos
{
    public static BuscarPedidoDto ConvertirDto(this Pedido entidad)
    {
        return new BuscarPedidoDto
        {
            Slug = entidad.Slug,
            UsuarioId = entidad.UsuarioId,
            FechaOrden = entidad.FechaPedido,
            Total = entidad.Total,
            Estado = entidad.Estado,
            Detalles = entidad.Detalles?.ConvertAll(x => x.ConvertirDto()) ?? new()
        };
    }
}
