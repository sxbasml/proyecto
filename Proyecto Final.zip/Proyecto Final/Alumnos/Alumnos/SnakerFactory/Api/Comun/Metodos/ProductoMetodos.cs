﻿using Api.Comun.Modelos.Productos;
using Api.Entidades;

namespace Api.Comun.Metodos;

public static class ProductoMetodos
{
    public static BuscarProductoDto ConvertirDto(this Producto entidad)
    {
        return new BuscarProductoDto
        {
            Slug = entidad.Slug,
            Nombre = entidad.Nombre,
            Descripcion = entidad.Descripcion,
            Precio = entidad.Precio,
            Stock = entidad.Stock,
            CategoriaNombre = entidad.Categoria?.Nombre ?? ""
        };
    }
}
