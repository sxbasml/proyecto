﻿using Api.Comun.Modelos.Carritos;
using Api.Entidades;

namespace Api.Comun.Metodos;

public static class DetalleCarritoMetodos
{
    public static BuscarCarritoDetalleDto ConvertirDto(this CarritoDetalle entidad)
    {
        return new BuscarCarritoDetalleDto
        {
            ProductoId = entidad.ProductoId,
            NombreProducto = entidad.Producto?.Nombre ?? "",
            Cantidad = entidad.Cantidad
        };
    }
}
