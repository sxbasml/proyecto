namespace Api.Comun.Interfaces;

public interface IHasherServicio
{
    string GenerarHash(string contrasena);
}