﻿using Api.Comun.Interfaces;

namespace Api.Entidades;

public class Pago : ISlug
{
    public int Id { get; set; }
    public int PedidoId { get; set; }
    public string MetodoPago { get; set; }
    public DateTime FechaPago { get; set; }
    public decimal Monto { get; set; }
    public string EstadoPago { get; set; }

    public virtual Pedido Pedido { get; set; }

    public string Slug { get; set; }

    public string ObtenerDescripcionParaSlug()
    {
        return $"Pago-{PedidoId}-{MetodoPago}";
    }
}
