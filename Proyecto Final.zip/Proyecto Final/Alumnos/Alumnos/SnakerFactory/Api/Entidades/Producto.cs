﻿using Api.Comun.Interfaces;

namespace Api.Entidades;

public class Producto : ISlug
{
    public int Id { get; set; }
    public string Nombre { get; set; }
    public string Descripcion { get; set; }
    public decimal Precio { get; set; }
    public string Marca { get; set; }
    public string Talla { get; set; }
    public int Stock { get; set; }
    public string ImagenUrl { get; set; }

    public int CategoriaId { get; set; }
    public virtual Categoria Categoria { get; set; }

    public string Slug { get; set; }

    public string ObtenerDescripcionParaSlug()
    {
        return $"{Nombre}-{Marca}-{Talla}";
    }
}
