﻿using Api.Comun.Interfaces;

namespace Api.Entidades;

public class Carrito : ISlug
{
    public int Id { get; set; }
    public int UsuarioId { get; set; }
    public DateTime FechaCreacion { get; set; }

    public virtual Usuario Usuario { get; set; }
    public virtual List<CarritoDetalle> Detalles { get; set; }

    public string Slug { get; set; }

    public string ObtenerDescripcionParaSlug()
    {
        return $"Carrito-{UsuarioId}-{FechaCreacion:yyyyMMddHHmmss}";
    }
}
