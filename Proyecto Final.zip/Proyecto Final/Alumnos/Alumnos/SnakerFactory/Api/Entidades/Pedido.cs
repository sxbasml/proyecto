﻿using Api.Comun.Interfaces;

namespace Api.Entidades;

public class Pedido : ISlug
{
    public int Id { get; set; }
    public int UsuarioId { get; set; }
    public DateTime FechaPedido { get; set; }
    public decimal Total { get; set; }
    public string Estado { get; set; }

    public virtual Usuario Usuario { get; set; }
    public virtual List<DetallePedido> Detalles { get; set; }

    public string Slug { get; set; }

    public string ObtenerDescripcionParaSlug()
    {
        return $"Pedido-{Id}-{UsuarioId}";
    }
}

